﻿# ============================================
# 《完蛋！如何逃离那个雨夜》
# Prologue + Chapter 1-3
# ============================================

# ----------------------------
# Characters
# ----------------------------

define d = Character("Dubasin")
define barja = Character("Kike Barja")
define asier = Character("Asier Bonel")
define mauro = Character("Mauro")
define raul = Character("Raúl Moro")
define monca = Character("Moncayola")
define unknown = Character("？")
define fan_a = Character("球迷A")
define fan_b = Character("球迷B")
define fan_c = Character("球迷C")
define staff = Character("工作人员")
define msg = Character("陌生号码")

# ----------------------------
# Variables
# ----------------------------

default doubt = 0
default secret = 0
default safety = 0
default barja_affection = 0

# ----------------------------
# Image
# ----------------------------

image dubasin = "images/dubasin.png"
image bonel = "images/bonel.png"
image mauro = "images/mauro.png"
image barja = "images/barja.png"



# ============================================
# START
# ============================================

label start:

    window hide       # ← 加这个：先不要显示白色对话框

    # 序章章节背景
    scene expression Transform(
    "images/chapter0_bg.png",
    xysize=(config.screen_width, config.screen_height)
)

    centered "序章"

    hide chapter0_bg

    scene black

    pause 1.0

    window show       # ← 加这个：到真正说话时再显示

    "后来有人问过我。"

    "如果重新来一次，我还会不会选择离开希洪。"

    "我想了很久。"

    "答案大概还是会。"

    "当时选择和希洪撕破脸的时候，我并不觉得有什么问题。"

    "毕竟是西甲。"

    "这样的机会，不是谁每年都会遇到。"

    "今年不走，明年还有没有，谁知道呢。"

    scene expression Transform(
    "images/1_bg.png",
    xysize=(config.screen_width, config.screen_height)
)

    "足球运动员的职业生涯没有那么长。"

    "有的时候，一个夏天就足够改变很多事情。"

    scene black
    
    with fade

    scene expression Transform(
    "images/2_bg.png",
    xysize=(config.screen_width, config.screen_height)
)


    "所以我来了。"

    "来到潘普洛纳。"

    scene black
    
    with fade

    scene expression Transform(
    "images/3_bg.png",
    xysize=(config.screen_width, config.screen_height)
)

    "来到奥萨苏纳。"

    "签合同，拍照，拿球衣，接受采访。"

    "然后对着镜头说那些每一个刚转会的人都会说的话。"

show dubasin:
    xalign 0.25
    yalign 1.0
    zoom 0.6

d "我很高兴来到这里。"

d "希望能够帮助球队。"

d "也希望尽快适应新的环境。"

hide dubasin
with dissolve

"标准答案。"

"没有一句是假话。"

"至少那个时候没有。"

"事情真正开始变得奇怪，是在几天以后。"

"而且一开始，真的只是一点点。"

"一点点奇怪。"

"一点点解释不清。"

"一点点让我觉得……"

"可能只是我想多了。"

"后来我才知道。"

"一个人在做出最错误的判断以前，通常都很喜欢说这句话。"

"“可能只是我想多了。”"

window hide       # ← 加这个：先不要显示白色对话框

jump chapter1

# ============================================
# CHAPTER 1
# ============================================

label chapter1:

    scene black
    with fade

    show chapter1_title:
        xalign 0.5
        yalign 0.5
        zoom 0.6

    pause 2.0

    hide chapter1_title
    with fade
    # 然后进入正文

    pause 1.5

    scene expression Transform(
    "images/chapter1_bg.png",
    xysize=(config.screen_width, config.screen_height)
)

    centered "第一章\初见端倪"

    scene black
    
    with fade

    pause 1.0

    window show       # ← 加这个：到真正说话时再显示

    scene expression Transform(
    "images/12_bg.png",
    xysize=(config.screen_width, config.screen_height)
)

    "我是在英国第一次正式见到大部分新队友和新教练的。"

    "季前集训。"

    "天气算不上好。"

    "风很大，天也一直阴着。"

    "不过至少不用顶着西班牙七八月的太阳训练。"

    "所以大家心情都还不错。"

    "除了我。"

    scene black
    
    with fade

    scene expression Transform(
    "images/13_bg.png",
    xysize=(config.screen_width, config.screen_height)
)

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "……"

    hide dubasin
    with dissolve

    "准确来说，我也没有心情不好。"

    "只是第一次进一支新球队的时候，总会有一点不知道该站在哪里。"

    "更何况奥萨苏纳和我以前待过的地方不太一样。"

    "训练基地的人很多。"

    "熟人也很多。"

    "当然。"

    "是他们彼此的熟人。"

    "不是我的。"

    "有人从我身边经过的时候，会拍拍另一个人的肩。"

    "有人坐下以后，根本不用问，就知道谁的水瓶是哪一个。"

    scene black
    
    with fade

    scene expression Transform(
    "images/14_bg.png",
    xysize=(config.screen_width, config.screen_height)
)


    "还有人隔着半个餐厅喊一个我完全没听过的昵称，对面竟然真的有人抬头。"

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "……"

    hide dubasin
    with dissolve

    "我拿着餐盘站了两秒。"

    "然后默默找了个空位坐下。"

    "新球队嘛。"

    "正常。"

    "我在心里这么告诉自己。"

    scene black
    
    with fade



    # ----------------------------
    # Dorm
    # ----------------------------

    scene expression Transform(
    "images/15_bg.png",
    xysize=(config.screen_width, config.screen_height)
)

    "宿舍也是提前分好的。"

    "我本来以为自己大概会和某个新队友住一起。"

    "结果拿到房卡的时候，上面只有一个名字。"

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "单人间？"

    hide dubasin
    with dissolve

    staff "是。"

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "挺好。"

    hide dubasin
    with dissolve

    "我是真的觉得挺好。"

    "不用和刚认识的人尴尬聊天。"

    "不用半夜听别人打呼噜。"

    "也不用思考“现在到底该不该关灯”这种属于集体生活的永恒难题。"

    "那时候我甚至觉得，运气不错。"

    "后来想想。"

    "很多事情如果一开始看起来太幸运……"

    "大概都应该稍微警惕一下。"

    scene black
    with fade


    # ----------------------------
    # Hallway
    # ----------------------------

    scene expression Transform(
    "images/16_bg.png",
    xysize=(config.screen_width, config.screen_height)
)

    "下午训练结束以后，我回去洗了个澡。"

    "刚从房间出来，就听见走廊拐角有人讲话。"

    unknown "（神秘语言）那个人是西班牙人吗？"

    unknown "（神秘语言）不知道。"

    unknown "（神秘语言）好像是比利时裔。"

    unknown "（神秘语言）可是他西班牙语说得很正常。"

    unknown "（神秘语言）那当然，他不是从小就在这里吗？"

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "……"

    hide dubasin
    with dissolve

    "我停下脚步。"

    "不是因为我听懂了。"

    "恰恰相反。"

    "我一个词都没听懂。"

    "只是一个人就算完全听不懂语言，也还是能分辨出来……"

    "对面的人正在说自己。"

    "因为他们一直在看我。"

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "？"

    hide dubasin
    with dissolve

    "两个看起来年纪很小的家伙站在自动贩卖机旁边。"

    "其中一个手里还拿着一瓶没开封的水。"

    "另一个靠着墙。"

    "两个人一边说，一边以一种完全不加掩饰的方式观察我。"

    "我开始怀疑。"

    "他们是不是忘记了人类拥有视线这种东西。"

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "……"

    hide dubasin
    with dissolve

    unknown "（神秘语言）他是不是发现了？"

    unknown "（神秘语言）不知道。"

    unknown "（神秘语言）应该没有吧。"

    "。"

    "当然没有。"

    "因为我一个字都听不懂。"

    # ----------------------------
    # Choice 1
    # ----------------------------

    menu:

        "要不要过去打招呼？"

        "过去打招呼":
            $ doubt += 1
            $ secret += 1

            jump choice1_yes

        "算了":
            $ secret += 2

            jump choice1_no

    scene black
    with fade

label choice1_yes:

    scene expression Transform(
    "images/17_bg.png",
    xysize=(config.screen_width, config.screen_height)
)

    "我想了一下。"

    "以后反正都是队友。"

    "一直这样互相看也很奇怪。"

    "于是我走了过去。"

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "你……们好？"

    hide dubasin
    with dissolve

    show bonel:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    asier "！"

    hide bonel
    with dissolve

    "左边那个明显吓了一跳。"

    show bonel:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    asier "你好！"

    asier "我是 Asier！"

    hide bonel
    with dissolve

    "他说得特别快。"

    "像是生怕我下一秒就问他刚才在说什么。"

    show mauro:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    mauro "Mauro。"

    hide mauro
    with dissolve

    "另一个倒是镇定很多。"

    "只是默默把刚才那瓶水拧开了。"

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "Jonathan。"

    hide dubasin
    with dissolve

    show bonel:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    asier "我们知道。"

    hide bonel
    with dissolve

    show mauro:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    mauro "。"

    hide mauro
    with dissolve

    show bonel:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    asier "……"

    asier "我是说，当然知道。"

    hide bonel
    with dissolve

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "……"

    hide dubasin
    with dissolve

    "很好。"

    "气氛变得更奇怪了。"

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "你们刚刚说的是……"

    hide dubasin
    with dissolve

    show bonel:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    asier "啊？"

    hide bonel
    with dissolve

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "那个语言。"

    d "我没听过。"

    hide dubasin
    with dissolve

    "Asier转头看了Mauro一眼。"

    "Mauro也看了他一眼。"

    "那是一个非常短暂的对视。"

    "但我不知道为什么，突然觉得自己好像错过了某种交流。"

    show mauro:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    mauro "巴斯克语。"

    hide mauro
    with dissolve

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "原来是巴斯克语。"

    hide dubasin
    with dissolve

    show bonel:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    asier "你没听懂吧？"

    hide bonel
    with dissolve

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "没有。"

    hide dubasin
    with dissolve

    show bonel:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    asier "那就好。"

    hide bonel
    with dissolve

    "。"

    show bonel:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    asier "……"

    asier "我是说……"

    hide bonel
    with dissolve

    "他明显准备补救。"

    "但很可惜。"

    "有人比他更快。"

    barja "Asier。"

    scene black
    with fade

    scene expression Transform(
    "images/18_bg.png",
    xysize=(config.screen_width, config.screen_height)
)

    "走廊另一边传来声音。"

    "我回头。"

    "早上和我打过招呼的队长正朝这边走过来。"

    scene black
    with fade

    scene expression Transform(
    "images/19_bg.png",
    xysize=(config.screen_width, config.screen_height)
)

    "Kike Barja。"

    "蓝色的眼睛。"

    "很显眼。"

    "那种大概会让很多女士印象深刻的蓝色。"

    scene black
    with fade

    scene expression Transform(
    "images/14_bg.png",
    xysize=(config.screen_width, config.screen_height)
)

    "当然，我之所以记得这么清楚，不是因为这个。"

    "主要是中午吃饭的时候，我恰好坐在他后面。"

    "他当时正在打电话。"

    show barja:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    barja "Pablico，不是这样。"

    barja "我跟你说了……"

    hide barja
    with dissolve

    "之后声音压低了。"

    "我没有继续听。"

    "毕竟偷听队长电话似乎不是融入新球队的最佳方式。"

    scene black
    with fade

    scene expression Transform(
    "images/18_bg.png",
    xysize=(config.screen_width, config.screen_height)
)

    "而现在。"

    "这个刚刚还在电话里叫别人“Pablico”的人走了过来。"

    "站到两个年轻人身后。"

    show barja:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    barja "。"

    hide barja
    with dissolve

    "抬手。"

    show bonel:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    asier "等等。"

    hide bonel
    with dissolve

    "一人一个脑门。"

    show bonel:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    asier "哎！"

    hide bonel
    with dissolve

    show mauro:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    mauro "……"

    hide mauro
    with dissolve

    show barja:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    barja "说西班牙语。"

    barja "我们在外面什么时候用巴斯克语讲话了？"

    hide barja
    with dissolve

    show bonel:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    asier "可是这里也没有别人。"

    hide bonel
    with dissolve

    show barja:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    barja "Jonathan不是人？"

    hide barja
    with dissolve

    show bonel:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    asier "……"

    hide bonel
    with dissolve

    show mauro:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    mauro "是。"

    hide mauro
    with dissolve

    show barja:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    barja "你还回答。"

    hide barja
    with dissolve

    "我站在旁边。"

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "……"

    hide dubasin
    with dissolve

    "不知道为什么。"

    "突然有一种自己闯进别人家客厅的感觉。"

    show barja:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    barja "行了。"

    barja "都走。"

    hide barja
    with dissolve

    "两个小孩明显早就习惯了。"

    "甚至没有反驳。"

    show bonel:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    asier "走了。"

    hide bonel
    with dissolve

    show mauro:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    mauro "再见，Jonathan。"

    hide mauro
    with dissolve

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "再见。"

    hide dubasin
    with dissolve

    "他们很快消失在走廊拐角。"

    "Barja转过来。"

    show barja:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    barja "别介意啊。"

    barja "他们年纪小，有时候讲话不过脑子。"

    hide barja
    with dissolve

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "没事。"

    d "他们就是在说我吧？"

    hide dubasin
    with dissolve

    show barja:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    barja "。"

    hide barja
    with dissolve

    "Barja停了一秒。"

    barja "你不是没听懂吗？"

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "……"

    d "所以真的是。"

    hide dubasin
    with dissolve

    show barja:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    barja "。"

    hide barja
    with dissolve

    "他笑了。"

    barja "你以后会习惯的。"

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "习惯什么？"

    hide dubasin
    with dissolve

    show barja:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    barja "奥萨苏纳。"

    hide barja
    with dissolve

    "他说完以后拍了拍我的肩。"

    show barja:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    barja "早点休息。"

    barja "明天训练强度不小。"

    hide barja
    with dissolve

    "然后也走了。"

    "我站在原地。"

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "……"

    hide dubasin
    with dissolve


    "这算回答了吗？"

    "好像算。"

    "又好像完全不算。"

    "我第一次产生了一个很轻微的疑问。"

    "这支球队……"

    "到底有多少事情是我不知道的？"

    scene black
    with fade

    jump chapter2


label choice1_no:

    "算了。"

    "第一天而已。"

    "没有必要什么事情都弄明白。"

    "而且直接走过去问“你们是不是在说我”，听起来多少有点自我意识过剩。"

    "我转身回房。"

    "房卡贴上门锁。"

    "滴。"

    "门开了。"

    "我进去以后没有立刻关门。"

    "只是很自然地把包放下。"

    "然后走廊里响起脚步声。"

    show barja:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    barja "Asier。"

    hide barja
    with dissolve

    "我认出了那个声音。"

    "队长。"

    "接着，又响起刚才那种我完全听不懂的语言。"

    show barja:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    barja "（神秘语言）以后别在他面前说。"

    hide barja
    with dissolve

    show bonel:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    asier "（神秘语言）他又听不懂。"

    hide bonel
    with dissolve

    show barja:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    barja "（神秘语言）听不懂也不行。"

    hide barja
    with dissolve

    show mauro:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    mauro "（神秘语言）知道了。"

    hide mauro
    with dissolve

    "。"

    "房间很安静。"

    "我站在床边。"

    "当然。"

    "一个字都没听懂。"

    "所以也没有任何理由觉得奇怪。"

    "我关上门。"

    "洗澡。"

    "整理东西。"

    "睡觉。"

    "一切都很正常。"

    "至少对我来说是这样。"

    scene black
    with fade

    jump chapter2


# ============================================
# CHAPTER 2
# ============================================

label chapter2:

    window hide       # ← 加这个：先不要显示白色对话框

    scene expression Transform(
    "images/21_bg.png",
    xysize=(config.screen_width, config.screen_height)
)

    centered "第二章\各有各的道理"

    scene black
    with fade

    pause 1.0

    window show       # ← 加这个：到真正说话时再显示

    scene expression Transform(
    "images/22_bg.png",
    xysize=(config.screen_width, config.screen_height)
)

    "季前赛结束以后，我们回了西班牙。"

    "真正的新赛季很快开始。"

    "然后我终于清楚地意识到一件事。"

    "西甲和西乙差别真是大……"

    "这不是我第一次知道。"

    "但“知道”和“真的站在场上”完全是两回事。"

    "比赛节奏更快。"

    "身体对抗更直接。"

    "有时候你觉得空间已经出来了。"

    "下一秒，它就没了。"

    "教练要求也更多。"

    "站位。"

    "回防。"

    "跑动。"

    "什么时候压。"

    "什么时候收。"

    "什么时候别像个傻子一样一个人冲出去。"

    "最后这一条虽然没人这么说。"

    "但大概就是这个意思。"

    "而且我所在的位置竞争也不轻松。"

    "队长 Kike Barja。"

    "还有那个加泰罗尼亚人。"

    "Raul Moro。"

    "Raul平时话不算特别多。"

    "有时候看起来甚至有点懒得参与周围的热闹。"

    "但踢球的时候是另一回事。"

    "快。"

    "很直接。"

    "还有一种让我很难形容的……"

    "自信。"

    "总而言之。"

    "位置竞争。"

    "正常。"

    "新球队磨合。"

    "正常。"

    "球迷盯着新援表现。"

    "也正常。"

    "真正不正常的是别的。"

    "比如奥萨苏纳这个俱乐部。"

    scene black
    with fade

    # ----------------------------
    # Phone Choice
    # ----------------------------

    scene expression Transform(
    "images/23_bg.png",
    xysize=(config.screen_width, config.screen_height)
)

    "第一次客场结束，回到酒店以后，我洗完澡躺在床上。"

    "手机就在旁边。"

    "屏幕亮了一次。"

    "又亮了一次。"

    "第三次的时候，我终于拿起来。"

    "社交媒体提醒。"

    "很多。"

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "……"

    hide dubasin
    with dissolve

    "我盯着屏幕。"

    "突然有一点不太想点开。"

    "职业球员最好不要在比赛以后看社交媒体。"

    "这个道理大家都知道。"

    "但职业球员在比赛以后还是会看社交媒体。"

    "这个事实大家也都知道。"

    scene black
    with fade

    menu:

        "要不要打开手机？"

        "打开":
            $ doubt += 2
            jump phone_open

        "关掉":
            $ secret += 2
            jump phone_close


label phone_open:

    scene expression Transform(
    "images/24_bg.png",
    xysize=(config.screen_width, config.screen_height)
)

    "我点开了。"

    "然后立刻后悔了。"

    "奥萨苏纳球迷实在太能上网。"

    "我不知道他们为什么有这么多时间。"

    "首页第一条。"

    "《Jonathan Dubasin 西甲进球等待记录 Day 21》"

    "配图是一只企鹅。"

    "企鹅站在冰面上。"

    "往前走了两步。"

    "摔倒。"

    "滑出去。"

    "撞进雪堆。"

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "……"

    hide dubasin
    with dissolve

    "下面评论很多。"

    fan_a "明天一定进。"

    fan_b "你昨天也是这么说的。"

    fan_c "企鹅已经比他先到禁区了。"

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "。"

    hide dubasin
    with dissolve

    "我继续往下划。"

    "第二条。"

    "《Day 22》"

    "还是那只企鹅。"

    "这次企鹅连冰坡都没爬上去。"

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "……"

    hide dubasin
    with dissolve

    "第三条。"

    "有人剪了我的射门集锦。"

    "标题是："

    "《他距离进球只差一点点，以及另外十三个一点点》"

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "……"

    hide dubasin
    with dissolve

    "播放量还很高。"

    "我点进去。"

    "第一脚。"

    "偏。"

    "第二脚。"

    "被扑。"

    "第三脚。"

    "被挡。"

    "第四脚。"

    "解说突然大叫。"

    "然后球飞上看台。"

    "我退出来。"

    "沉默几秒。"

    scene black
    with fade

    scene expression Transform(
    "images/25_bg.png",
    xysize=(config.screen_width, config.screen_height)
)

    "又点回去。"

    "举报。"

    "理由：骚扰。"

    "系统弹出提示。"

    "“感谢你的反馈。”"

    "不到一分钟。"

    "“经审核，该内容未违反社区规范。”"

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "……"

    d "好。"


    hide dubasin
    with dissolve

    scene black
    with fade

    scene expression Transform(
    "images/26_bg.png",
    xysize=(config.screen_width, config.screen_height)
)


    "我把手机放下。"

    "过了一会，又拿起来。"

    "这次没看球迷。"

    "只是重新看了比赛录像。"

    "第一遍。"

    "没什么。"

    "第二遍。"

    "还是没什么。"

    "第三遍的时候。"

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "……"

    hide dubasin
    with dissolve

    "我把进度条拉回去。"

    "暂停。"

    "往前五秒。"

    "播放。"

    "再暂停。"

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "防守很奇怪。"

    hide dubasin
    with dissolve

    "不是整体阵型的问题。"

    "也不是谁漏了人。"

    "至少我第一眼看不出来。"

    "而是有几个瞬间。"

    "我明明觉得大家应该在看球。"

    "可他们没有。"

    "Barja回头看了一眼替补席。"

    "Raul看了一眼边线。"

    "Moncayola在球已经转移以后，还多看了某个方向两秒。"

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "……"

    hide dubasin
    with dissolve

    "我又拉回去。"

    "重新放。"

    "还是一样。"

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "他们在看什么？"

    hide dubasin
    with dissolve

    "我不知道。"

    "画面很普通。"

    "普通到让我觉得自己的问题非常愚蠢。"

    "也许只是战术。"

    "也许是教练指令。"

    "也许只是我的错觉。"

    scene black
    with fade

    scene expression Transform(
    "images/25_bg.png",
    xysize=(config.screen_width, config.screen_height)
)

    "我退出录像。"

    "重新打开社交媒体。"

    "那只企鹅还在首页。"

    show dubasin:
        xalign 0.25
        yalign 1.0
        zoom 0.6

    d "……"

    hide dubasin
    with dissolve

    "举报。"

    "理由：骚扰。"

    scene black
    with fade

    window hide       # ← 加这个：先不要显示白色对话框

    centered "CONTINUING……"

    pause 2.0

    return

label phone_close:

    scene expression Transform(
    "images/23_bg.png",
    xysize=(config.screen_width, config.screen_height)
)

    "算了。"

    "不看。"

    "我把手机扣在桌面上。"

    "这种时候看到任何东西都只会影响睡眠。"

    "我躺下。"

    "闭眼。"

    "酒店隔音一般。"

    "走廊上偶尔有人经过。"

    "不知道过了多久。"

    "外面又响起脚步声。"

    unknown "（神秘语言）他没看？"

    unknown "（神秘语言）没有。"

    unknown "（神秘语言）确定？"

    unknown "（神秘语言）手机一直没动。"

    unknown "（神秘语言）那挺好的。"

    "脚步声停了一会。"

    unknown "（神秘语言）明天呢？"

    unknown "（神秘语言）明天再说。"

    "然后声音消失了。"

    "我翻了个身。"

    "什么都不知道。"

    "睡得很好。"

    scene black
    with fade

    centered "CONTINUING……"

    window hide       # ← 加这个：先不要显示白色对话框

    pause 2.0

    return